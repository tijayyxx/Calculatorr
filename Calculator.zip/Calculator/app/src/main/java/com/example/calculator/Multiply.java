package com.example.calculator;

public class Multiply {
}
