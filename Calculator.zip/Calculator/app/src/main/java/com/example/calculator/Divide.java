package com.example.calculator;

public class Divide {
}
